from .unique_symbols_vlad import get_parser, cli, unique_characters
